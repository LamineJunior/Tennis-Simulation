
from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3, os

app = Flask(__name__)
app.secret_key = 'rptennis_secret_key'
DB_PATH = 'database.sqlite'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/match')
def match():
    return render_template('match.html')

@app.route('/tournament')
def tournament():
    return render_template('tournament.html')

@app.route('/career')
def career():
    return render_template('career.html')

if __name__ == '__main__':
    app.run(debug=True)
